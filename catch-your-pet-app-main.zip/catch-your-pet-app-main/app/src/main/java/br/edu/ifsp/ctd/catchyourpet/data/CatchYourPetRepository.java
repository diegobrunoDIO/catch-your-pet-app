package br.edu.ifsp.ctd.catchyourpet.data;

import br.edu.ifsp.ctd.catchyourpet.data.remote.CatchYourPetApi;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class CatchYourPetRepository {

    private static final String REMOTE_API_URL = "https://diegobrunodio.github.io/catch-your-pet-api/";

    //region Atributo que encapsula o acesso a nossa API (Retrofit).
    private final CatchYourPetApi api;

    public CatchYourPetApi getApi() {
        return api;
    }
    //endregion

    //region Padrão de Projeto Singleton: garante uma instância única do atributo do Retrofit.
    private CatchYourPetRepository() {
        api = new Retrofit.Builder()
                .baseUrl(REMOTE_API_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(CatchYourPetApi.class);
    }

    public static CatchYourPetRepository getInstance() {
        return LazyHolder.INSTANCE;
    }

    private static class LazyHolder {
        private static final CatchYourPetRepository INSTANCE = new CatchYourPetRepository();
    }
    //endregion
}
