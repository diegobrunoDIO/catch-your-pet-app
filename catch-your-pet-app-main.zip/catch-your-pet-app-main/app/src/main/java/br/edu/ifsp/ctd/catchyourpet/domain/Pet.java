package br.edu.ifsp.ctd.catchyourpet.domain;

public class Pet {
    private String title;
    private String description;
    private String image;
    private Location location;
    private Contact contact;

    public String getTitle() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getImage() {
        return image;
    }

    public Location getLocation() {
        return location;
    }

    public Contact getContact() {
        return contact;
    }

}
