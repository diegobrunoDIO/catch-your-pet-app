package br.edu.ifsp.ctd.catchyourpet.ui.adapters;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.color.MaterialColors;
import com.karumi.dexter.Dexter;
import com.karumi.dexter.listener.PermissionGrantedResponse;
import com.karumi.dexter.listener.single.BasePermissionListener;
import com.squareup.picasso.Picasso;

import java.util.List;

import br.edu.ifsp.ctd.catchyourpet.R;
import br.edu.ifsp.ctd.catchyourpet.databinding.PetsItemBinding;
import br.edu.ifsp.ctd.catchyourpet.domain.Pet;

public class PetsAdapter extends RecyclerView.Adapter<PetsAdapter.ViewHolder> {

    private final List<Pet> pets;

    public PetsAdapter(List<Pet> pets) {
        this.pets = pets;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        PetsItemBinding binding = PetsItemBinding.inflate(layoutInflater, parent, false);
        return new ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Context context = holder.itemView.getContext();

        Pet pet = this.pets.get(position);
        holder.binding.tvTitle.setText(pet.getTitle());
        holder.binding.tvDescription.setText(pet.getDescription());

        Picasso.get().load(pet.getImage())
                .placeholder(R.drawable.ic_downloading)
                .fit()
                .into(holder.binding.ivPetImage);

        holder.binding.btCall.setOnClickListener(view -> executeActionCall(context, pet));
        holder.binding.btMaps.setOnClickListener(view -> executeActionMaps(context, pet));
    }

    @Override
    public int getItemCount() {
        return this.pets.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private final PetsItemBinding binding;

        public ViewHolder(PetsItemBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    private void executeActionCall(Context context, Pet pet) {
        Dexter.withContext(context)
                .withPermission(Manifest.permission.CALL_PHONE)
                .withListener(new BasePermissionListener() {
                    @Override
                    public void onPermissionGranted(PermissionGrantedResponse permissionGrantedResponse) {
                        final Intent intent = new Intent(Intent.ACTION_CALL);
                        intent.setData(Uri.parse(String.format("tel:%s", pet.getContact().getPhone())));
                        context.startActivity(intent);
                        super.onPermissionGranted(permissionGrantedResponse);
                    }
                }).check();
    }

    private void executeActionMaps(Context context, Pet pet) {
        final String url = String.format("https://www.google.com/maps/dir/?api=1&destination=%s", pet.getLocation());
        final Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        context.startActivity(intent);
    }
}
