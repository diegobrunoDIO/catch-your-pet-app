package br.edu.ifsp.ctd.catchyourpet.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;

import com.google.android.material.snackbar.Snackbar;

import java.util.List;

import br.edu.ifsp.ctd.catchyourpet.R;
import br.edu.ifsp.ctd.catchyourpet.data.CatchYourPetRepository;
import br.edu.ifsp.ctd.catchyourpet.data.remote.CatchYourPetApi;
import br.edu.ifsp.ctd.catchyourpet.databinding.ActivityMainBinding;
import br.edu.ifsp.ctd.catchyourpet.domain.Pet;
import br.edu.ifsp.ctd.catchyourpet.ui.adapters.PetsAdapter;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = MainActivity.class.getSimpleName();

    private ActivityMainBinding binding;
    private PetsAdapter petsAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        this.setupPetList();
        this.setupPetsRefresh();
    }

    private void setupPetList() {
        binding.rvPets.setLayoutManager(new LinearLayoutManager(this));
        binding.rvPets.setAdapter(petsAdapter);
        findPetsFromApi();
    }

    private void setupPetsRefresh() {
        binding.srlPets.setOnRefreshListener(this::findPetsFromApi);
    }

    private void findPetsFromApi() {
        binding.srlPets.setRefreshing(true);
        final CatchYourPetApi api = CatchYourPetRepository.getInstance().getApi();
        api.getPets().enqueue(new Callback<List<Pet>>() {
            @Override
            public void onResponse(@NonNull Call<List<Pet>> call, @NonNull Response<List<Pet>> response) {
                if (response.isSuccessful()) {
                    List<Pet> matches = response.body();
                    petsAdapter = new PetsAdapter(matches);
                    binding.rvPets.setAdapter(petsAdapter);
                } else {
                    showErrorMessage();
                }
                binding.srlPets.setRefreshing(false);
            }

            @Override
            public void onFailure(@NonNull Call<List<Pet>> call, @NonNull Throwable error) {
                Log.e(TAG, error.getMessage(), error);
                showErrorMessage();
                binding.srlPets.setRefreshing(false);
            }
        });
    }

    private void showErrorMessage() {
        Snackbar.make(binding.rvPets, R.string.error_api, Snackbar.LENGTH_LONG).show();
    }

}