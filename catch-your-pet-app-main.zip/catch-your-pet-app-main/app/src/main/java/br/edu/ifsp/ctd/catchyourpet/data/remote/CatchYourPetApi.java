package br.edu.ifsp.ctd.catchyourpet.data.remote;

import java.util.List;

import br.edu.ifsp.ctd.catchyourpet.domain.Pet;
import retrofit2.Call;
import retrofit2.http.GET;

public interface CatchYourPetApi {

    @GET("animais.json")
    Call<List<Pet>> getPets();
}
